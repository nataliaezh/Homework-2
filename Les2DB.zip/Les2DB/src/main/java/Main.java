import java.util.Random;
import java.util.Arrays;

import static java.util.Arrays.sort;

public class Main {

    public static void main(String[] args) {
        int[] array = new int[10000];
        Random rnd = new Random();
        for (int i = 0; i < array.length; i++) {
            array[i] = rnd.nextInt();
            System.out.println("arr[" + i + "]=" + array[i]);
        }
        System.out.println("Числа в массиве сгенерированы.");

        sort(array);

        for (int x : array) {
            System.out.println(x);
        }
    }
}